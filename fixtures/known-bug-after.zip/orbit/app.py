def health():
    """Liveness probe (v2)."""
    return {"status": "ok", "version": 2}
