"""Startup check: verifies required settings exist before the app boots."""
from pathlib import Path

REQUIRED = ["SECRET_KEY", "DATABASE_URL"]


def load(path):
    cfg = {}
    for line in Path(path).read_text().splitlines():
        line = line.strip()
        if line and not line.startswith("#") and "=" in line:
            key, value = line.split("=", 1)
            cfg[key.strip()] = value.strip()
    return cfg


def main():
    cfg = load(".env.example")
    for key in REQUIRED:
        if key not in cfg:
            raise RuntimeError(f"Startup check failed: missing required setting {key}")
    print("Startup check passed: all required settings present")


if __name__ == "__main__":
    main()
