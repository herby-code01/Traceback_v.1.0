from pathlib import Path

if not Path("data/seed.db").exists():
    raise SystemExit("seed database not found: data/seed.db (provisioned outside the repo)")
print("ok")
