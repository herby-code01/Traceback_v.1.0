def health():
    """Liveness probe."""
    return {"status": "ok"}
